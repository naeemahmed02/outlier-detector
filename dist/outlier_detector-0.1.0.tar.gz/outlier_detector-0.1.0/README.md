# Outlier Detector

A Python library for detecting outliers in datasets using IQR and Z-score methods.

## Installation
```bash
pip install outlier-detector
